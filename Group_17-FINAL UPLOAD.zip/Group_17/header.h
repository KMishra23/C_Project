#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#pragma pack (1)
//some global variables declared that we have used across functions
struct IFD ifd;
short int Content;
short int bits_per_sample;
short int samples_per_pixel;
int height;
int width;

//struct to store IFD data temporarily
struct IFD {
    short int Tag;
    short int Data_Type;
    int length_info;
    int info;   
};

//struct to create BMP Header
struct BMP_Header {
        int size;
        int width;
        int height;
        short int bytes_per_pixel;
        int image_size;
        int Xres;
        int Yres;
};

//struct that is used as an array to store pixel data(written as BGR since in bmp data is stored in reverse order(bottom up))
struct RGB {
    unsigned char blue;
    unsigned char green;
    unsigned char red;
};

//struct that stores tiff headder data
struct _TiffHeader
{
    short int  Identifier;  /* Byte-order Identifier */
    short int  Version;     /* TIFF version number (always 2Ah) */
	int IFDOffset;   /* Offset of the first Image File Directory*/
}TIFHEAD;